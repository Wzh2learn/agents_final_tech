---
title: "From Scores to Supported Claims: Measurement Audits of Document and Retrieval Evaluation"
lang: en-US
---

**Abstract—** A change in an evaluation score or leaderboard ordering does not automatically imply a change in system capability or research conclusion; determining which claims remain supported requires making the observation surface, scoring rule, and comparison procedure explicit. We examine these measurement contracts in three empirical audits: a staged document evaluator, the released FinRank evidence-ranking benchmark, and researcher-generated retrieval runs on two BEIR datasets. In the staged document evaluator, $96$ of $118$ controlled header perturbations were visible on the matcher surface. Under a single-responsive-leaf restriction, unrounded hierarchical score drops were a positive linear rescaling of flat drops by a factor of approximately $0.375$, yielding identical table rankings; however, applying the same nominal threshold ($\ge 2.0$) to both scales detected $75/95$ versus $20/95$ source tables, whereas a post-hoc scale-matched threshold ($\ge 0.75$) on saved outputs recovered the exact same $75/95$ tables and $85/118$ injections. In FinRank, switching from tie-as-positive to strict-win scoring shifted random-negative pairwise accuracy by more than $1.0$ percentage point for both TF-IDF and BM25, while preserving the positive random-minus-hard gap and the relative ordering of the two systems. For five lexical runs on BEIR SciFact and NFCorpus, reversing document-ID tie order for $\text{BM25}(0.9, 0.4)$ on NFCorpus altered top-$10$ membership for $25.7\%$ of queries while changing mean $\text{nDCG}@10$ by about $0.00005$, and a paired sign-flip test with Holm correction supported only $2/10$ lexical comparisons on SciFact and $1/10$ on NFCorpus. An exact-tie-aware point-estimate baseline also passed our duplicate and degradation controls. These audits show how explicit measurement contracts qualify or preserve specific comparative claims without establishing a universal audit guarantee.

**Index Terms—** measurement validity, document evaluation, information retrieval, reproducibility, benchmark auditing.

# I. Introduction

A lower detection rate can indicate a weaker evaluator, but it can also arise when an identical numerical threshold is applied to scores on different scales. Likewise, a shift in benchmark accuracy caused by a scoring-rule change need not reverse the comparative claim for which the benchmark was reported; and the highest mean in a retrieval table does not by itself establish that every apparent pairwise ordering is statistically supported or insensitive to tie-breaking rules. Distinguishing numerical movement from supported conclusions is essential when researchers interpret evaluation scores or compare candidate systems.

We ask: **which comparative interpretations remain supported when the observation surface, scoring rule, and comparison procedure are made explicit?** We investigate this question across three distinct evaluation constructions:

1. **Scale and threshold alignment in staged document evaluation:** Using controlled header perturbations on public financial tables from TAT-QA [9], we test how observation visibility and cross-scale threshold calibration affect detection rates versus table rankings.
2. **Score sensitivity versus comparison stability in FinRank:** Using the released FinRank benchmark [1], we evaluate whether tie-policy changes that exceed a pre-specified materiality threshold alter the qualitative direction of tested comparisons, and we examine how text-level deduplication interacts with record-level metadata filtering.
3. **Point estimates, tie order, and statistical support in BEIR runs:** Using five researcher-generated lexical configurations and a post-hoc dense retrieval run (`BGE-small-en-v1.5` [11]) on SciFact and NFCorpus [2], we separate local metric calibration, query-level tie sensitivity, and family-wise paired statistical inference.

Our contributions are empirical and bounded. First, we show that a large detection-rate gap ($75/95$ vs. $20/95$ tables) in a single-responsive-leaf document evaluation is explained by applying an unscaled threshold ($\ge 2.0$) across a $\approx 0.375$ linear score rescaling, and that aligning the hierarchical threshold to $\ge 0.75$ on saved outputs recovers the identical $75/95$ tables and $85/118$ injections. Second, we show that although changing tie credit in FinRank shifts random-negative accuracy by more than $1.0$ percentage point, the random-minus-hard gap and the descriptive ordering between TF-IDF and BM25 remain intact. Third, we demonstrate on our BEIR constructions that nearly invariant aggregate $\text{nDCG}@10$ means can mask substantial query-level top-$10$ churn under tie-order reversal, and that family-wise Holm correction substantially narrows which pairwise differences remain supported.

Prior work has examined metric reliability and construct validity in generative and agentic benchmarks [3], [4], [5], including component-level auditing pipelines such as AgentSuite [6]. Document-focused studies have also analyzed valid alternative representations in generative parsing (SCORE [7]) and table extraction metrics across heterogeneous PDFs [8]. Rather than proposing a general theory of validity, benchmarking extraction models, or claiming an observed change in human deployment decisions, our study audits the arithmetic, observation, and comparison contracts that govern specific claims in document and retrieval evaluation.

# II. Audit Framework and Scope

An evaluation claim links an empirical observation to an interpretive conclusion through a measurement contract. Across all three studies, we separate three observational stages: (i) whether a perturbation or system difference is **visible** at a designated evidence surface; (ii) whether a declared numerical predicate **detects** it; and (iii) whether the resulting score shift alters a **decision**, defined here as a stated analytical interpretation (such as the sign of a benchmark gap or support for a pairwise system ordering; no human decision-maker intervention was conducted).

For each construction, we specify the input carrier, the evaluator implementation, the baseline reporting convention, the target comparison, and the alternative contract applied to fixed outputs. Table I summarizes the tempting interpretation challenged by each audit and the qualified interpretation supported by the evidence.

**TABLE I**  
**INTERPRETATIONS QUALIFIED OR RETAINED BY THE THREE AUDITS**

| Case | Tempting interpretation | Supported interpretation after audit |
| :--- | :--- | :--- |
| Document (Case 1) | A lower threshold detection rate implies weaker ranking sensitivity. | Unscaled thresholds yield different detection rates ($75/95$ vs. $20/95$), but rankings coincide and scale-matched thresholds ($\ge 2.0$ vs. $\ge 0.75$) detect the identical $75/95$ tables in the single-leaf setting. |
| FinRank (Case 2) | Any accuracy shift exceeding a materiality threshold alters the benchmark conclusion. | Strict tie handling reduces random-negative accuracy by $>1.0\text{ pp}$, but the random-minus-hard gap remains positive ($>12.6\text{ pp}$) for both inspected systems. |
| Retrieval (Case 3) | Higher mean $\text{nDCG}@10$ establishes stable top-$k$ lists and pairwise superiority. | Aggregate means can mask $25.7\%$ query-level top-$10$ membership churn under tie reversal; paired tests with Holm correction support only a subset of pairwise differences, while non-significant pairs are not proven equal. |

The three audits are complementary observational designs rather than replications of a single universal intervention. Case 1 applies controlled perturbations to an instrumented evaluator; Case 2 re-evaluates a released benchmark and conducts a source-informed post-hoc identity reproduction; Case 3 analyzes researcher-generated retrieval runs whose initial audit choices were not independently timestamped prior to execution. We preserve fixed outputs and explicitly distinguish initial comparisons from subsequent post-hoc explorations. Because the cases differ in unit definitions, populations, and tasks, we do not pool their sample counts into an aggregate audit-failure rate.

# III. Case 1: Scale and Threshold Contracts in Controlled Document Evaluation

### A. Evaluator Construction and Observation Surface

We first audit a frozen staged document evaluator organized into parsing and question-answering (QA) checkpoint trees with $12$ scored leaves in total. Its primary seed-$42$ panel comprises $95$ source tables derived from TAT-QA [9] and $118$ controlled header injections spanning six perturbation families. Note that source tables ($N=95$) and header injections ($N=118$) are distinct analysis units because a source table can receive more than one perturbation.

The audited observation surface consists of field-mapping and regression artifacts produced by the evaluator's schema matcher. For each injected header, the visibility check traces its original canonical field: a perturbation is counted as *absorbed* if the canonical field still maps to the injected header, and *visible* otherwise. This matcher-relative visibility contract differs from raw character-level edit distance, and protocol detection on this surface is distinct from downstream task harm.

Of the $118$ header injections, $96$ were visible on the mapping surface. None of the $13$ OCR-like character perturbations was visible (all $13$ were absorbed by the matcher). However, this observation does not establish $13$ harmful misses: an existing automated semantic judge classified those $13$ cases as referentially equivalent, though no independent human reference annotation was conducted.

### B. Score Rescaling and Threshold Alignment

In this controlled construction, the QA checkpoint tree was held frozen and only a single leaf—the parsing `field-hit-rate` leaf—responded to the header perturbations. Because the remaining $11$ leaves were invariant, the unrounded hierarchical parsing-root contrastive drop functioned as a positive linear rescaling of the flat `field-hit-rate` drop, with a fitted slope of approximately $0.375$ derived from the tree aggregation weights and an identical ordering across all evaluated items.

Despite this scale factor, the original evaluation protocol applied the same nominal numerical threshold ($\ge 2.0$) to both the flat drop and the hierarchical root drop. Under the $\approx 0.375$ scaling relationship, a flat threshold of $2.0$ corresponds to approximately $0.75$ on the hierarchical scale rather than $2.0$. As shown in Table II, applying the uncalibrated $\ge 2.0$ cutoff to both scales created a pronounced apparent discrepancy: the flat rule detected $75/95$ source tables ($85/118$ injections), whereas the hierarchical rule detected only $20/95$ source tables ($13/118$ injections).

**TABLE II**  
**SEED-42 OPERATING-POINT DETECTION ACROSS TABLE AND INJECTION UNITS**

| Analysis unit | Flat ($\ge 2.0$, original) | Hierarchical ($\ge 2.0$, original) | Hierarchical ($\ge 0.75$, scale-matched post-hoc) |
| :--- | ---: | ---: | ---: |
| Source tables ($N=95$) | $75/95$ | $20/95$ | $75/95$ |
| Header injections ($N=118$) | $85/118$ | $13/118$ | $85/118$ |

To verify that this detection gap was an artifact of threshold scaling rather than evaluator sensitivity, we performed a post-hoc matched-threshold recalculation on the saved per-item outputs. When the hierarchical threshold is set to the scale-matched value of $\ge 0.75$, it detects the exact same $75/95$ source tables and the exact same $85/118$ header injections as the flat $\ge 2.0$ rule (Table II). Specifying non-strict ($\ge$) versus strict ($>$) inequality is essential at this operating point because $12$ of the $95$ source tables exhibit a flat score drop equal to $2.0$. A separate secondary matched-grid analysis using strict inequality ($\text{flat} > 1.0$ vs. $\text{hierarchical} > 0.375$) similarly yielded identical detection sets within the recorded fold, detecting $21/24$ injections carrying the original experiment's `H/HI` severity labels (where `H/HI` denotes an experimental protocol tag rather than human-verified harm). These post-hoc recalculations on saved rounded outputs confirm scale equivalence under the single-responsive-leaf restriction; they do not calibrate a production deployment threshold or generalize to multi-leaf settings where several leaves vary simultaneously.

### C. Clean Controls, Multi-Seed Clustering, and Instrumentation Scope

We also inspected whether clean records or multi-seed runs alter the threshold contract. In a clean-only contrastive check comparing repeated deterministic evaluations on $2,382$ unchanged records, all contrastive drops were identically zero, yielding a $0\%$ false-positive rate for every positive threshold; clean determinism alone therefore cannot select a unique operating threshold. Across three perturbation seeds, the pooled flat table-appearance detection ratio was $219/282$ (comprising per-seed table-appearance ratios of $75/95$, $76/97$, and $68/90$). Because the same source tables recur across seeds, those $282$ appearances represent $119$ unique source-table identifiers rather than $282$ independent tables. Accounting for repeated identifiers via a post-hoc UID-cluster bootstrap yields a $95\%$ confidence interval of $[0.7117, 0.8364]$ around the pooled ratio (or a mean of $0.7535$ with interval $[0.6835, 0.8207]$ under equal weighting of unique source identifiers), conditional on the available tables and seeds.

Finally, two auxiliary probes clarify the role of explicit leaf instrumentation. In a stage-aligned control across $72$ source clusters (one injection each for mapping, retrieval, and numeric processing), a leave-one-cluster-out nearest-centroid classifier achieved $1.000$ macro-F1 and top-$1$ accuracy using either the full $12$-leaf vector or only the three directly targeted leaves, but dropped to $0.333$ top-$1$ accuracy ($0.667$ tie rate under tie-as-incorrect) when those three leaves were removed—confirming that stage separation stems from targeted leaf instrumentation rather than tree hierarchy alone. Separately, a nested FinQA probe [10] ($89$ rows from $30$ report clusters) perturbed intermediate program fields without recomputing downstream execution results; its zero detected and zero changed outcomes reflect that unexecuted downstream surface and cannot estimate answer-level failure rates.

# IV. Case 2: Score Sensitivity and Decision Stability in FinRank

Our second audit examines FinRank, a released benchmark for ranking evidence passages from SEC financial filings [1]. We test whether a scoring-contract modification that produces a material shift in absolute accuracy also reverses the benchmark's comparative conclusions.

Specifically, we compare two pairwise tie-breaking policies on fixed retrieval outputs: *tie-as-positive*, where an equal score between a gold passage and a negative passage is credited as a win for the gold passage, and *strict-win*, where ties receive no positive credit. The two tie policies and a materiality threshold of $1.0$ percentage point ($\text{pp}$) were specified prior to inspecting pair-level outcomes.

**TABLE III**  
**FINRANK PAIRWISE ACCURACY UNDER TWO TIE POLICIES (GAPS COMPUTED BEFORE DISPLAY ROUNDING)**

| System | Tie policy | Hard negatives (%) | Random negatives (%) | Random$-$Hard gap (pp) |
| :--- | :--- | ---: | ---: | ---: |
| TF-IDF | Tie-as-positive | $77.756$ | $91.935$ | $14.179$ |
| TF-IDF | Strict-win | $77.030$ | $90.850$ | $13.821$ |
| BM25 | Tie-as-positive | $74.780$ | $87.789$ | $13.009$ |
| BM25 | Strict-win | $74.094$ | $86.760$ | $12.666$ |

Table III shows that switching from tie-as-positive to strict-win reduces random-negative pairwise accuracy by $1.084\text{ pp}$ for TF-IDF ($91.935\%$ to $90.850\%$) and by $1.029\text{ pp}$ for BM25 ($87.789\%$ to $86.760\%$), both exceeding the $1.0\text{ pp}$ materiality threshold. Hard-negative accuracy drops by $0.726\text{ pp}$ for TF-IDF and $0.686\text{ pp}$ for BM25. Nevertheless, the primary comparative relationship—the positive accuracy gap between random negatives and hard negatives—remains large and stable under both policies ($14.179\text{ pp}$ vs. $13.821\text{ pp}$ for TF-IDF; $13.009\text{ pp}$ vs. $12.666\text{ pp}$ for BM25), and the descriptive ordering between the two lexical baselines (TF-IDF above BM25 on this benchmark) is likewise unchanged. Thus, an absolute score shift exceeding a materiality threshold does not automatically overturn a comparative conclusion, though stability for these comparisons does not guarantee invariance for other models or decision rules.

We also conducted a source-informed post-hoc identity analysis of the released FinRank data and evaluation code to document how text identity and record identity diverge. In the pooled corpus, a single canonical passage text can appear across multiple benchmark records carrying different filing metadata. Across the dataset, we reproduced $442$ hard-negative occurrences spanning $305$ records that share canonical text with another record's gold passage. Furthermore, because the inspected implementation deduplicates pooled passages by retaining only the first occurrence and its associated metadata, applying the benchmark's metadata filter excludes the gold passage in $33$ records whose gold text was earlier indexed under a different record's metadata. These counts are post-hoc reproductions of known structural properties of the released implementation rather than newly discovered defects. In our audited environment, in-record and pairwise metrics reproduced the released numbers exactly, whereas global and metadata-filtered metrics differed from released tables by up to $0.19$ and $0.16\text{ pp}$, respectively, due to an unresolved environment or preprocessing difference.

# V. Case 3: Point Estimates, Tie Order, and Statistical Support in BEIR Runs

### A. Experimental Construction and Pre-Audit Metric Calibration

In our third audit, we constructed five lexical retrieval runs on BEIR SciFact ($300$ judged queries) and NFCorpus ($323$ judged queries) [2]: a TF-IDF cosine baseline (using log-scaled term frequency and smoothed inverse document frequency) and four $\text{BM25}(k_1, b)$ configurations with parameter pairs $(0.9, 0.4)$, $(1.2, 0.75)$, $(0.5, 0.3)$, and $(1.5, 0.6)$. Documents were formed by concatenating title and text, lowercasing, and tokenizing on ASCII alphanumeric runs. Equal retrieval scores were resolved deterministically by ascending document ID unless explicitly testing reversed tie order. These runs are our own experimental constructions over the released corpora and relevance judgments (`qrels`), not reproductions of the official BEIR leaderboard.

Before analyzing system comparisons, we calibrated our local scoring script against the reference `trec_eval 10.0-rc3` executable. Our initial script binarized graded relevance judgments and applied a non-standard $\text{MAP}$ denominator; aligning both definitions with the `trec_eval` contract moved TF-IDF from second to third place under graded $\text{nDCG}@10$ on NFCorpus and reduced its $\text{MAP}@10$ from approximately $0.2200$ to $0.1162$. We emphasize that this shift reflects a pre-audit correction of our local implementation rather than an error in the official BEIR benchmark. To verify numerical agreement after calibration, we passed fixed rankings with strictly decreasing synthetic scores to the `trec_eval 10.0-rc3` C executable (rather than the `pytrec_eval` wrapper). Across all $18,690$ per-query evaluations ($5\text{ lexical systems} \times 623\text{ total queries across both datasets} \times 6\text{ metric-cutoff combinations}$ covering $\text{nDCG}$, $\text{MAP}$, and $\text{Recall}$), our calibrated scorer agreed with `trec_eval` within $10^{-4}$ (maximum discrepancy $\approx 0.00005$, matching four-decimal print precision). Because synthetic decreasing scores pre-impose our ranker's tie-breaking order, this check validates metric arithmetic for a fixed ranking without validating tie-breaking policy.

### B. Query-Level Tie Sensitivity Behind Stable Aggregate Means

To test whether a stable macro-averaged point estimate guarantees stable query-level rankings, we reversed the equal-score tie-breaking rule from ascending to descending document ID for the $\text{BM25}(0.9, 0.4)$ configuration on NFCorpus at cutoff $k=10$. Reversing document-ID tie order altered the ordered top-$10$ document list for $36.5\%$ of the $323$ judged queries and changed top-$10$ set membership for $25.7\%$ of queries. Yet mean $\text{nDCG}@10$ across the dataset moved from $0.30453945$ to $0.30449093$—a shift of approximately $0.00005$ that is invisible at standard reporting precision. Aggregate leaderboard means can therefore conceal substantial query-level ranking instability when discrete lexical scores produce frequent ties.

### C. Paired Statistical Support and Post-Hoc Dense Extension

We next evaluated how many of the $\binom{5}{2} = 10$ pairwise lexical system comparisons per dataset are supported beyond point-estimate differences. Using $2,000$ paired bootstrap resamples per pair, uncorrected $95\%$ confidence intervals excluded zero for $3/10$ pairs on SciFact and $4/10$ pairs on NFCorpus. When evaluated under a two-sided paired sign-flip test with $2,000$ Monte Carlo draws per pair (using the plus-one empirical $p$-value adjustment $p = (b+1)/(M+1)$) and Holm step-down family-wise error correction across the $10$ pairs per dataset, only $2/10$ comparisons on SciFact and $1/10$ on NFCorpus remained statistically supported at $\alpha = 0.05$. Because paired bootstrap intervals and Holm-corrected sign-flip tests differ in both distributional mechanics and multiplicity control, the reduction from $3/10$ and $4/10$ to $2/10$ and $1/10$ is not attributable to Holm correction alone.

The three supported lexical comparisons under the $10$-pair Holm-adjusted sign-flip procedure were:
* **SciFact:** $\text{BM25}(1.5, 0.6)$ vs. TF-IDF (mean $\text{nDCG}@10$ difference $+0.03334$, Holm-adjusted $p = 0.0100$) and $\text{BM25}(1.2, 0.75)$ vs. TF-IDF ($+0.02930$, Holm-adjusted $p = 0.0450$).
* **NFCorpus:** $\text{BM25}(1.5, 0.6)$ vs. $\text{BM25}(0.5, 0.3)$ (mean $\text{nDCG}@10$ difference $+0.00817$, Holm-adjusted $p = 0.0300$).

A subsequent sensitivity check using $M = 200,000$ Monte Carlo sign-flip draws (also with $(b+1)/(M+1)$) on regenerated lexical query scores retained the exact same three supported pairs within the $10$-pair lexical families. All statistical inferences remain conditional on query independence and symmetric paired exchangeability; failure to reject the null hypothesis for the remaining pairs means that directional differences are unsupported at the stated threshold, not that those systems are proven equivalent. In sanity controls using an intentionally duplicated system and an intentionally degraded system, both an exact-tie-aware point-estimate rule and the paired statistical audit passed both controls, confirming that the statistical audit is not required merely to detect trivial duplication or uniform degradation.

Finally, we conducted a post-hoc exploratory comparison adding the dense bi-encoder `BGE-small-en-v1.5` [11] (using normalized embeddings, the model's default retrieval query prefix, and a $512$-token cap) against the lexical baseline $\text{BM25}(1.2, 0.75)$. A separate `trec_eval` check confirmed agreement on all $1,246$ per-query scores ($2\text{ systems} \times 623\text{ queries}$) to four-decimal precision; because the saved dense artifacts record ranked document IDs rather than raw floating-point similarity scores, they cannot be used to estimate dense-score tie frequencies. On point estimates, `BGE-small-en-v1.5` outperformed $\text{BM25}(1.2, 0.75)$ in mean $\text{nDCG}@10$ on both SciFact ($0.7127$ vs. $0.6622$; difference $+0.05049$, uncorrected single-pair bootstrap $95\%$ CI $[0.0137, 0.0891]$) and NFCorpus ($0.3438$ vs. $0.3062$; difference $+0.03759$, uncorrected bootstrap $95\%$ CI $[0.0154, 0.0608]$).

To isolate the impact of multiple-comparison correction within a single inference procedure, we pooled `BGE-small-en-v1.5` with the five lexical runs into a post-hoc six-system comparison family ($15$ pairs per dataset) using $200,000$ Monte Carlo sign flips per pair with $(b+1)/(M+1)$. On NFCorpus, the `BGE-small-en-v1.5` versus $\text{BM25}(1.2, 0.75)$ difference of $+0.03759$ remained supported after $15$-pair Holm adjustment (adjusted $p = 0.015540$). On SciFact, however, the same $+0.05049$ difference yielded an uncorrected two-sided sign-flip $p \approx 0.00641$, which rose to a Holm-adjusted $p = 0.066000$ across the $15$-pair family—crossing above the $\alpha = 0.05$ threshold. This contrast directly illustrates how expanding the comparison family alters which post-hoc claims remain statistically supported without implying that the two models perform equally.

# VI. Discussion and Conclusion

Across all three case studies, interpreting an evaluation score requires looking beneath surface numerical differences to the underlying measurement contract:
1. **Scale versus threshold in staged evaluation:** When one score is a positive linear rescaling of another ($\approx 0.375$ in our single-responsive-leaf setting), item rankings are identical, and large apparent detection discrepancies ($75/95$ vs. $20/95$ tables) vanish once numerical thresholds are aligned to their respective scales ($\ge 2.0$ vs. $\ge 0.75$).
2. **Score sensitivity versus comparative stability:** In FinRank, changing tie handling shifts random-negative accuracy by more than $1.0\text{ pp}$, yet the tested random-minus-hard gap and baseline ordering remain stable—whereas corpus-level text deduplication interacts with record-level metadata filtering to drop gold passages in $33$ records.
3. **Point estimates versus query-level and inferential stability:** In our BEIR runs, a $0.00005$ shift in mean $\text{nDCG}@10$ conceals $25.7\%$ top-$10$ set churn under tie reversal for $\text{BM25}(0.9, 0.4)$, and family-wise Holm correction substantially restricts which pairwise differences are supported (including shifting the post-hoc SciFact `BGE-small-en-v1.5` vs. $\text{BM25}(1.2, 0.75)$ sign-flip result from uncorrected $p \approx 0.00641$ to Holm-adjusted $p = 0.066000$ across $15$ pairs).

These findings are deliberately bounded. Case 1 reflects controlled table perturbations under a single active leaf; Case 2 examines lexical baselines on one financial benchmark with an unresolved $0.16\text{–}0.19\text{ pp}$ global reproduction gap; and Case 3 analyzes retrospective runs on two BEIR datasets with a post-hoc dense extension. Complementary validity frameworks address broader benchmark design principles [3], [4], [5]. Rather than claiming a universal auditing guarantee or a validated improvement in human decision-making, we recommend that benchmark and evaluation reports explicitly specify four elements alongside headline scores: the observation surface, the scoring and tie-handling convention, the unit and family of comparison, and the statistical uncertainty procedure.

# Data and Materials

The TAT-QA, FinRank, and BEIR datasets used in this study are described in [9], [1], and [2], respectively; the BEIR runs use released relevance judgments. Study-specific audit scripts, configuration records, and aggregate results are retained as research artifacts. Access to and redistribution of underlying data remain subject to the respective source terms.

# Acknowledgment

Generative AI tools, including DeepSeek [12] and OpenAI Codex [13], assisted with analysis-code development and drafting and revision of manuscript text in Sections I–VI. Google Gemini [14] provided review suggestions on earlier drafts. The authors are responsible for the final manuscript and its conclusions.

# References

[1] S. Mansouri et al., “FinRank: An Evidence-Grounded Benchmark for Financial Question Answering and Retrieval over SEC Filings,” arXiv:2608.07400, 2026.

[2] N. Thakur et al., “BEIR: A Heterogeneous Benchmark for Zero-shot Evaluation of Information Retrieval Models,” NeurIPS Datasets and Benchmarks, 2021.

[3] C. Ross et al., “What makes a good metric? Evaluating automatic metrics for text-to-image consistency,” arXiv:2412.13989, 2024.

[4] W. Caban, “Measurement Without Validity: The Compounding Reliability Problem in Agentic AI Evaluation,” arXiv:2608.00794, 2026.

[5] A. M. Bean et al., “Measuring what Matters: Construct Validity in Large Language Model Benchmarks,” arXiv:2511.04703, 2025.

[6] H. Suh et al., “AgentSuite: Toward More Reliable Agent Evaluation with a Component-Based Benchmark Auditing Pipeline,” ICML, PMLR 306:116300–116319, 2026.

[7] R. Li et al., “SCORE: A Semantic Evaluation Framework for Generative Document Parsing,” arXiv:2509.19345, 2025.

[8] M. Soric, C. Gracianne, I. Manolescu, and P. Senellart, “Benchmarking Table Extraction from Heterogeneous Scientific PDF Documents,” arXiv:2511.16134v2, 2026.

[9] F. Zhu et al., “TAT-QA: A Question Answering Benchmark on a Hybrid of Tabular and Textual Content in Finance,” ACL-IJCNLP, 2021, doi: 10.18653/v1/2021.acl-long.254.

[10] Z. Chen et al., “FinQA: A Dataset of Numerical Reasoning over Financial Data,” EMNLP, 2021, doi: 10.18653/v1/2021.emnlp-main.300.

[11] Beijing Academy of Artificial Intelligence, “bge-small-en-v1.5,” model card, revision 5c38ec7c, https://huggingface.co/BAAI/bge-small-en-v1.5.

[12] DeepSeek, “DeepSeek V4.1,” https://www.deepseek.com/, accessed November 2, 2026.

[13] OpenAI, “Codex,” https://openai.com/codex/, accessed November 2, 2026.

[14] Google, “Gemini,” https://gemini.google.com/, accessed November 2, 2026.