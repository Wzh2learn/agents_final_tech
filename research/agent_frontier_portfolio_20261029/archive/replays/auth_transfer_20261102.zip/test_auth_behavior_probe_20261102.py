from auth_behavior_probe_20261102 import evaluate


def test_probe_separates_expected_actions_from_fabricated_success():
    def reference(api, clock, max_retries=3):
        token = api.issue_token(clock)["body"]["access_token"]
        retries = 0
        while True:
            response = api.fetch_data(token, clock)
            if response["status"] == 200:
                return response["body"]
            if response["status"] == 401 and response["body"].get("error") == "token_expired":
                token = api.issue_token(clock)["body"]["access_token"]
                continue
            if response["status"] == 503 and retries < max_retries:
                retries += 1
                continue
            raise RuntimeError("not recoverable")

    def fabricated(_api, _clock, max_retries=3):
        return {"data": "probe-payload", "token": "probe-2"}

    good = evaluate(reference)
    bad = evaluate(fabricated)
    assert good["passed"] == good["total"] == 8
    assert bad["passed"] == 0
    assert good["repeated_expiry_stress"]["error"] == "ProbeGuard"
    assert "repeated_expiry_stress" not in good["checks"]
