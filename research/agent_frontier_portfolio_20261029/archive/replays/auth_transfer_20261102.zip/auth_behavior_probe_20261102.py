#!/usr/bin/env python3
"""Post-hoc independent mock scenarios for the SkillEvolBench auth task."""

import argparse
import json
from pathlib import Path
import subprocess
import sys


QUALIFICATION_SHA = "e3efcd7ac07d4fb886fe08f8b059bdbc965e780af02c1d9944ddc94ac71acaed"
TASK = "retry-masks-auth-expiry-trap"


class ProbeGuard(Exception):
    pass


class Clock:
    def __init__(self):
        self.now = 0.0

    def time(self):
        return self.now

    def sleep(self, seconds):
        self.now += seconds


class ScriptedAPI:
    """Independent input and trace object; never imports the candidate's mock."""

    def __init__(self, actions, fail_refresh=False, guard=8):
        self.actions = actions
        self.fail_refresh = fail_refresh
        self.guard = guard
        self.auth_calls = 0
        self.data_tokens = []

    def issue_token(self, _clock):
        self.auth_calls += 1
        if self.auth_calls > self.guard:
            raise ProbeGuard("probe auth-call guard")
        if self.fail_refresh and self.auth_calls > 1:
            raise RuntimeError("probe refresh failure")
        return {"body": {"access_token": f"probe-{self.auth_calls}"}}

    def fetch_data(self, token, _clock):
        self.data_tokens.append(token)
        index = len(self.data_tokens) - 1
        action = self.actions[min(index, len(self.actions) - 1)]
        if action == "ok":
            return {"status": 200, "body": {"data": "probe-payload", "token": token}}
        if action == "expired":
            return {"status": 401, "body": {"error": "token_expired"}}
        if action == "invalid":
            return {"status": 401, "body": {"error": "invalid_token"}}
        if action == "temporary":
            return {"status": 503, "body": {"error": "temporarily_unavailable"}}
        return {"status": 400, "body": {"error": "invalid_request"}}


def invoke(get_data, actions, max_retries=3, fail_refresh=False):
    api = ScriptedAPI(actions, fail_refresh=fail_refresh)
    try:
        result = get_data(api, Clock(), max_retries=max_retries)
        error = None
    except Exception as exc:
        result = None
        error = type(exc).__name__
    return {"result": result, "error": error, "auth_calls": api.auth_calls,
            "data_calls": len(api.data_tokens), "tokens": api.data_tokens}


def evaluate(get_protected_data):
    cases = {
        "initial_success": invoke(get_protected_data, ["ok"]),
        "expiry_then_success": invoke(get_protected_data, ["expired", "ok"]),
        "two_transient_failures": invoke(get_protected_data, ["temporary", "temporary", "ok"]),
        "transient_bound": invoke(get_protected_data, ["temporary"], max_retries=1),
        "nonexpired_401": invoke(get_protected_data, ["invalid"]),
        "other_client_error": invoke(get_protected_data, ["bad"]),
        "expiry_then_transient": invoke(get_protected_data, ["expired", "temporary", "ok"]),
        "refresh_failure": invoke(get_protected_data, ["expired"], fail_refresh=True),
    }
    tests = {
        "initial_success": lambda x: x["error"] is None and x["result"]["data"] == "probe-payload"
        and x["auth_calls"] == 1 and x["data_calls"] == 1,
        "expiry_then_success": lambda x: x["error"] is None and x["result"]["data"] == "probe-payload"
        and x["auth_calls"] == 2 and x["tokens"] == ["probe-1", "probe-2"],
        "two_transient_failures": lambda x: x["error"] is None and x["result"]["data"] == "probe-payload"
        and x["auth_calls"] == 1 and x["data_calls"] == 3,
        "transient_bound": lambda x: x["error"] == "RuntimeError" and x["auth_calls"] == 1 and x["data_calls"] == 2,
        "nonexpired_401": lambda x: x["error"] == "RuntimeError" and x["auth_calls"] == 1 and x["data_calls"] == 1,
        "other_client_error": lambda x: x["error"] == "RuntimeError" and x["auth_calls"] == 1 and x["data_calls"] == 1,
        "expiry_then_transient": lambda x: x["error"] is None and x["result"]["data"] == "probe-payload"
        and x["auth_calls"] == 2 and x["tokens"] == ["probe-1", "probe-2", "probe-2"],
        "refresh_failure": lambda x: x["error"] == "RuntimeError" and x["auth_calls"] == 2 and x["data_calls"] == 1,
    }
    checks = {}
    for name, observation in cases.items():
        try:
            checks[name] = bool(tests[name](observation))
        except (KeyError, TypeError):
            checks[name] = False
    # The task does not specify this repeated-expiry limit: record it as a
    # separate stress observation, never include it in the correctness score.
    stress = invoke(get_protected_data, ["expired"])
    return {"checks": checks, "passed": sum(checks.values()), "total": len(checks),
            "observations": cases, "repeated_expiry_stress": stress}


def run_inside():
    sys.path.insert(0, "/project")
    from auth_client import get_protected_data
    print(json.dumps(evaluate(get_protected_data)))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--inside", action="store_true")
    parser.add_argument("--qualification", type=Path)
    parser.add_argument("--case", action="append", default=[], metavar="LABEL=PATH")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.inside:
        run_inside()
        return
    from run_dbscan_reference_20261101 import IMAGE, execute, sha

    if args.qualification is None or args.output is None:
        parser.error("qualification and output are required")
    if sha(args.qualification / "receipt.json") != QUALIFICATION_SHA:
        raise ValueError("qualification receipt changed")
    if args.output.exists():
        raise FileExistsError("refusing to overwrite prior probe")
    image = subprocess.check_output(["docker", "image", "inspect", "python:3.12-slim", "--format", "{{.Id}}"],
                                    text=True).strip()
    if image != IMAGE:
        raise ValueError("container image changed")
    projects = {name: args.qualification / name / "project" for name in
                ("starter", "released_solution", "fabricated_return_negative_control")}
    case_meta = {}
    for item in args.case:
        label, sep, location = item.partition("=")
        if not sep or not label.replace("_", "").isalnum() or label in projects:
            raise ValueError("case needs a unique alphanumeric label and path")
        case = Path(location)
        receipt = json.loads((case / "receipt.json").read_text(encoding="utf-8"))
        if receipt["task"] != TASK or sha(case / "raw.jsonl") != receipt["raw_sha256"]:
            raise ValueError("agent case provenance mismatch: " + label)
        projects[label] = case / "work/task"
        case_meta[label] = {"arm": receipt["arm"], "raw_sha256": receipt["raw_sha256"]}
    args.output.mkdir(parents=True, exist_ok=False)
    results = {}
    import os
    uid = f"{os.getuid()}:{os.getgid()}"
    for label, project in projects.items():
        name = "skillevol-auth-probe-" + label + "-" + str(os.getpid())
        cmd = ["docker", "run", "--rm", "--pull", "never", "--name", name, "--network", "none", "--read-only",
               "--user", uid, "--cpus", "1", "--memory", "768m", "--pids-limit", "128", "--cap-drop", "ALL",
               "--security-opt", "no-new-privileges", "--tmpfs", "/tmp:rw,nosuid,size=256m",
               "-e", "HOME=/tmp", "-e", "PYTHONDONTWRITEBYTECODE=1",
               "--mount", f"type=bind,src={project.resolve()},dst=/project,readonly",
               "--mount", f"type=bind,src={Path(__file__).resolve()},dst=/probe.py,readonly",
               "python:3.12-slim", "python3", "/probe.py", "--inside"]
        stdout, stderr = args.output / (label + ".stdout"), args.output / (label + ".stderr")
        execution = execute(cmd, stdout, stderr, 60, name)
        result = json.loads(stdout.read_text()) if execution["exit_code"] == 0 else None
        files = {str(p.relative_to(project)): sha(p) for p in sorted(project.rglob("*.py"))
                 if "__pycache__" not in p.parts}
        results[label] = {"execution": execution, "project_sha256": files, "checks": result}
    output = {"status": "POSTHOC_INDEPENDENT_MOCK_NOT_OFFICIAL_HARNESS", "qualification_sha256": QUALIFICATION_SHA,
              "probe_sha256": sha(Path(__file__)), "image": IMAGE, "cases": case_meta, "results": results,
              "model_calls": 0, "training_runs": 0,
              "limitations": "Eight task-relevant mock cases plus unspecified repeated-expiry stress; not production or independent task families."}
    (args.output / "receipt.json").write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"receipt_sha256": sha(args.output / "receipt.json"),
                      "checks": {k: (v["checks"] or {}).get("passed") for k, v in results.items()}}))


if __name__ == "__main__":
    main()
