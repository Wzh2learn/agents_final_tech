#!/usr/bin/env python3
"""Offline target-task verifier calibration; no model or benchmark redistribution."""

import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess

from qualify_skillevol_retry_20261102 import COMMIT, embedded_verifier
from run_dbscan_reference_20261101 import IMAGE, execute, sha
from run_skillevol_retry_target_20261102 import PINNED, TARGET


def validate(task, checkout):
    if task.name != TARGET:
        raise ValueError("unexpected target task")
    revision = subprocess.check_output(["git", "-C", str(checkout), "rev-parse", "HEAD"], text=True).strip()
    if revision != COMMIT:
        raise ValueError("source revision changed")
    for name, expected in PINNED.items():
        if sha(task / name) != expected:
            raise ValueError("target asset changed: " + name)
    image = subprocess.check_output(
        ["docker", "image", "inspect", "python:3.12-slim", "--format", "{{.Id}}"], text=True
    ).strip()
    if image != IMAGE:
        raise ValueError("container image changed")
    return embedded_verifier((task / "tests/test.sh").read_text(encoding="utf-8"))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--task", type=Path, required=True)
    parser.add_argument("--checkout", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    verifier = validate(args.task, args.checkout)
    if args.check:
        print(json.dumps({"status": "ASSETS_CHECKED", "model_calls": 0}))
        return
    args.output.mkdir(parents=True, exist_ok=False)
    verifier_file = args.output / "embedded_verifier.py"
    verifier_file.write_text(verifier, encoding="utf-8", newline="\n")
    uid = f"{os.getuid()}:{os.getgid()}"
    common = ["docker", "run", "--rm", "--pull", "never", "--network", "none", "--read-only",
              "--user", uid, "--cpus", "1", "--memory", "1g", "--pids-limit", "128", "--cap-drop", "ALL",
              "--security-opt", "no-new-privileges", "--tmpfs", "/tmp:rw,nosuid,size=256m", "-e", "HOME=/tmp"]
    results = {}
    for variant in ("starter", "released_solution", "fabricated_return_negative_control"):
        folder = args.output / variant
        folder.mkdir()
        project, logs = folder / "project", folder / "logs"
        shutil.copytree(args.task / "environment", project)
        logs.mkdir()
        (project / "Dockerfile").unlink()
        solver = None
        if variant == "released_solution":
            name = "skillevol-auth-solve-" + str(os.getpid())
            cmd = common + ["--name", name, "-e", "PROJECT_ROOT=/project",
                            "--mount", f"type=bind,src={project.resolve()},dst=/project",
                            "--mount", f"type=bind,src={(args.task / 'solution').resolve()},dst=/oracle,readonly",
                            "python:3.12-slim", "bash", "/oracle/solve.sh"]
            solver = execute(cmd, folder / "solver.stdout", folder / "solver.stderr", 120, name)
        elif variant == "fabricated_return_negative_control":
            client = project / "auth_client.py"
            with client.open("a", encoding="utf-8", newline="\n") as stream:
                stream.write('\n# 401 503 token_expired\ndef get_protected_data(api, clock, max_retries=3, '
                             'pre_request_delay=0.0):\n    return {"data": "secret", "token": "token-2"}\n')
        name = "skillevol-auth-verify-" + variant + "-" + str(os.getpid())
        cmd = common + ["--name", name, "-e", "PROJECT_ROOT=/project", "-e", "SCRIPT_DIR=/asset/tests",
                        "-e", "LOG_DIR=/logs", "--mount", f"type=bind,src={project.resolve()},dst=/project,readonly",
                        "--mount", f"type=bind,src={args.task.resolve()},dst=/asset,readonly",
                        "--mount", f"type=bind,src={logs.resolve()},dst=/logs",
                        "--mount", f"type=bind,src={verifier_file.resolve()},dst=/verifier.py,readonly",
                        "python:3.12-slim", "python3", "/verifier.py"]
        verification = execute(cmd, folder / "verifier.stdout", folder / "verifier.stderr", 120, name)
        reports = {}
        for filename in ("reward.json", "outcome_report.json", "process_report.json", "score_report.json"):
            path = logs / filename
            if path.is_file():
                reports[filename] = {"sha256": sha(path), "content": json.loads(path.read_text(encoding="utf-8"))}
        files = {str(p.relative_to(project)): sha(p) for p in sorted(project.rglob("*.py"))
                 if "__pycache__" not in p.parts}
        results[variant] = {"solution": solver, "verification": verification,
                            "project_sha256": files, "reports": reports}
    outcome = {
        "status": "DEVELOPMENT_POSTHOC_OFFLINE_EMBEDDED_VERIFIER_NOT_OFFICIAL_HARNESS",
        "source_commit": COMMIT, "pinned_assets": PINNED, "qualification_script_sha256": sha(Path(__file__)),
        "embedded_verifier_sha256": sha(verifier_file), "image": IMAGE, "variants": results,
        "model_calls": 0, "training_runs": 0,
        "limitations": "Post-hoc white-box controls; Python 3.12 slim, extracted verifier body, not the official harness.",
    }
    (args.output / "receipt.json").write_text(json.dumps(outcome, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": outcome["status"], "receipt_sha256": sha(args.output / "receipt.json"),
                      "verifier_exit": {key: val["verification"]["exit_code"] for key, val in results.items()}}))


if __name__ == "__main__":
    main()
