from pathlib import Path

import pytest

import qualify_skillevol_auth_20261102 as qualification


def test_changed_task_asset_stops_before_container_inspection(monkeypatch, tmp_path):
    commands = []

    def fake_output(args, **_kwargs):
        commands.append(args)
        if args[0] != "git":
            raise AssertionError("must reject altered task before inspecting the container")
        return qualification.COMMIT + "\n"

    monkeypatch.setattr(qualification.subprocess, "check_output", fake_output)
    monkeypatch.setattr(qualification, "sha", lambda _path: "changed")
    with pytest.raises(ValueError, match="target asset changed"):
        qualification.validate(tmp_path / qualification.TARGET, Path(tmp_path))
    assert len(commands) == 1 and commands[0][0] == "git"
