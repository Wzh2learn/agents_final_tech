#!/usr/bin/env python3
"""Reconcile real auth-task episodes with saved qualification and behavior probes."""

import argparse
import json
from pathlib import Path

from auth_behavior_probe_20261102 import QUALIFICATION_SHA, TASK
from run_dbscan_reference_20261101 import sha
from run_retry_feedback_controls_20261102 import SOURCE_RAW_HASH


PROBE_SHA = "76a45f3de7d3e620f6bd5f7243a2ac519835eabc2524fb53f64c1211a06ecc46"
EXPECTED = {"no_history": "no_skill", "optional": "source_program_plus_feedback", "required": "source_program_required"}


def audit_trace(raw):
    direct_reads, unsuccessful_reads, other_mentions, edits = [], [], [], []
    events = [json.loads(line) for line in raw.read_text(encoding="utf-8").splitlines() if line]
    for event in events:
        if event.get("type") != "tool_use":
            continue
        part = event.get("part", {})
        tool = part.get("tool")
        state = part.get("state", {})
        item = state.get("input", {})
        if tool == "read" and "prior_" in str(item.get("filePath", "")):
            if state.get("status") == "completed" and isinstance(state.get("output"), str) and state["output"]:
                direct_reads.append(item["filePath"])
            else:
                unsuccessful_reads.append(item["filePath"])
        elif tool in ("bash", "grep", "glob") and "prior_" in json.dumps(item):
            other_mentions.append(tool)
        elif tool in ("edit", "write"):
            edits.append(item.get("filePath", ""))
    return {"prior_file_read_paths": direct_reads, "unsuccessful_prior_reads": unsuccessful_reads,
            "other_prior_tool_mentions": other_mentions, "edit_paths": edits}


def usage_summary(steps):
    keys = ("input", "output", "reasoning", "total")
    sums = {key: sum(p.get(key, 0) or 0 for p in steps) for key in keys}
    sums["cache_read"] = sum((p.get("cache") or {}).get("read", 0) or 0 for p in steps)
    sums["steps"] = len(steps)
    sums["missing_total_steps"] = sum("total" not in p or p["total"] is None for p in steps)
    return sums


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--qualification", type=Path, required=True)
    parser.add_argument("--probe", type=Path, required=True)
    parser.add_argument("--source-case", type=Path, required=True)
    parser.add_argument("--case", action="append", default=[], metavar="LABEL=PATH")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError("refusing to overwrite existing summary")
    if sha(args.qualification / "receipt.json") != QUALIFICATION_SHA or sha(args.probe / "receipt.json") != PROBE_SHA:
        raise ValueError("qualification or behavioral probe receipt changed")
    behavioral = json.loads((args.probe / "receipt.json").read_text(encoding="utf-8"))
    source_receipt = json.loads((args.source_case / "receipt.json").read_text(encoding="utf-8"))
    if (source_receipt.get("task") != "429-with-retry-after-header"
            or source_receipt["raw_sha256"] != SOURCE_RAW_HASH
            or sha(args.source_case / "raw.jsonl") != SOURCE_RAW_HASH):
        raise ValueError("source Agent raw changed")
    source = {"raw_sha256": source_receipt["raw_sha256"],
              "posts": sum(x.startswith("POST ") for x in source_receipt["model_http_requests"]),
              "reported_usage": usage_summary(source_receipt["step_finish_tokens"])}
    cases = {}
    for item in args.case:
        label, sep, path = item.partition("=")
        if not sep or label not in EXPECTED or label in cases:
            raise ValueError("unexpected or duplicate case label")
        case = Path(path)
        receipt = json.loads((case / "receipt.json").read_text(encoding="utf-8"))
        intervention = json.loads((case / "intervention.json").read_text(encoding="utf-8"))
        if (receipt["task"] != TASK or receipt["arm"] != EXPECTED[label]
                or intervention["condition"] not in ("no_history", EXPECTED[label])
                or sha(case / "raw.jsonl") != receipt["raw_sha256"]):
            raise ValueError("case provenance mismatch: " + label)
        report = json.loads((case / "verifier_logs/score_report.json").read_text(encoding="utf-8"))
        dimensions = {d["name"]: {"passed": d["tests_passed"], "total": d["tests_matched"]}
                      for d in report["dimensions"]}
        probe = behavioral["results"][label]["checks"]
        project = behavioral["results"][label]["project_sha256"]
        current = {str(p.relative_to(case / "work/task")): sha(p) for p in sorted((case / "work/task").rglob("*.py"))
                   if "__pycache__" not in p.parts}
        if current != project or behavioral["cases"][label]["raw_sha256"] != receipt["raw_sha256"]:
            raise ValueError("project changed since behavioral probe: " + label)
        cases[label] = {"arm": receipt["arm"], "raw_sha256": receipt["raw_sha256"],
                        "intervention_sha256": sha(case / "intervention.json"),
                        "agent_exit": receipt["agent_exit"], "verifier_exit": receipt["verifier_exit"],
                        "posts": sum(x.startswith("POST ") for x in receipt["model_http_requests"]),
                        "reported_usage": usage_summary(receipt["step_finish_tokens"]),
                        "elapsed_seconds": receipt["elapsed_seconds"],
                        "score_report_sha256": sha(case / "verifier_logs/score_report.json"),
                        "released_dimensions": dimensions, "released_weighted_score": report["total_score"],
                        "behavior_passed": probe["passed"], "behavior_total": probe["total"],
                        "repeated_expiry_stress": probe["repeated_expiry_stress"],
                        "project_sha256": project, "trace": audit_trace(case / "raw.jsonl")}
    if set(cases) != set(EXPECTED):
        raise ValueError("all three target conditions are required")
    output = {"status": "POSTHOC_DEVELOPMENT_NOT_OFFICIAL_HARNESS", "source": source, "cases": cases,
              "qualification_sha256": QUALIFICATION_SHA, "behavior_probe_sha256": PROBE_SHA,
              "source_cost_is_shared_not_additive_between_history_arms": True,
              "limitations": "One exposed task family; forced access condition was designed after earlier outputs; total usage includes reported cache reads."}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"summary_sha256": sha(args.output), "conditions": list(cases)}))


if __name__ == "__main__":
    main()
