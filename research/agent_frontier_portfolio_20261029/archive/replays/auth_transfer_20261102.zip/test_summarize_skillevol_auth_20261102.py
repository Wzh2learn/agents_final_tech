import json

from summarize_skillevol_auth_20261102 import audit_trace, usage_summary


def test_glob_is_not_mistaken_for_reading_history(tmp_path):
    events = [
        {"type": "tool_use", "part": {"tool": "glob", "state": {"input": {"pattern": "/root/prior_*"}}}},
        {"type": "tool_use", "part": {"tool": "read", "state": {"status": "completed", "output": "feedback",
                                                                "input": {"filePath": "/root/prior_feedback.txt"}}}},
        {"type": "tool_use", "part": {"tool": "read", "state": {"status": "error", "error": "missing",
                                                                "input": {"filePath": "/root/prior_missing.txt"}}}},
        {"type": "tool_use", "part": {"tool": "edit", "state": {"input": {"filePath": "/root/task/auth_policy.py"}}}},
    ]
    raw = tmp_path / "raw.jsonl"
    raw.write_text("\n".join(json.dumps(event) for event in events), encoding="utf-8")
    result = audit_trace(raw)
    assert result["prior_file_read_paths"] == ["/root/prior_feedback.txt"]
    assert result["unsuccessful_prior_reads"] == ["/root/prior_missing.txt"]
    assert result["other_prior_tool_mentions"] == ["glob"]
    assert result["edit_paths"] == ["/root/task/auth_policy.py"]


def test_usage_explicitly_flags_missing_totals():
    result = usage_summary([{"input": 3, "output": 2, "total": 9, "cache": {"read": 4}}, {"input": 1}])
    assert result["total"] == 9 and result["cache_read"] == 4
    assert result["steps"] == 2 and result["missing_total_steps"] == 1
