#!/usr/bin/env python3
"""Bind source/target receipts, history reads and strict task checks."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from qualify_continual_office import check_toc


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def one(root: Path, pattern: str) -> Path:
    matches = [p for p in root.glob(pattern) if p.is_dir()]
    if len(matches) != 1:
        raise ValueError(f"expected one episode for {pattern}, found {len(matches)}")
    return matches[0]


def summarize(path: Path, document: str | None) -> dict:
    receipt_path = path / "receipt.json"
    intervention_path = path / "intervention.json"
    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    intervention = json.loads(intervention_path.read_text(encoding="utf-8"))
    if receipt["task"] != f"office-ind-{intervention['task']:03d}" or receipt["arm"] != intervention["condition"]:
        raise ValueError("episode identity differs from intervention")
    raw_path = path / "raw.jsonl"
    if receipt["raw_sha256"] != sha(raw_path):
        raise ValueError("raw trace differs from receipt")
    events = [json.loads(line) for line in raw_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    reads = []
    errors = []
    for event in events:
        if event.get("type") == "error":
            errors.append(event.get("error", {}).get("name", "UNKNOWN"))
        part = event.get("part", {})
        state = part.get("state", {})
        inp = state.get("input", {})
        if event.get("type") == "tool_use" and part.get("tool") == "read":
            name = inp.get("filePath", "")
            if Path(name).name in ("source_history.json", "source_skill.md"):
                reads.append({"file": name, "status": state.get("status"),
                              "nonempty_output": bool(str(state.get("output", "")).strip()),
                              "permission_error": "external_directory" in str(state.get("error", ""))})
    out = path / ("work/output.html" if intervention["task"] == 5 else "work/toc.json")
    parsed = None
    strict = None
    if document is not None and out.exists():
        try:
            parsed = json.loads(out.read_text(encoding="utf-8"))
            strict = check_toc(parsed, document)
        except (OSError, ValueError, TypeError):
            strict = False
    token_events = receipt["step_finish_tokens"]
    tokens = {key: sum(int(row.get(key, 0) or 0) for row in token_events)
              for key in ("total", "input", "output", "reasoning")}
    tokens["cache_read"] = sum(int(row.get("cache", {}).get("read", 0) or 0) for row in token_events)
    return {"task": intervention["task"], "condition": intervention["condition"],
            "agent_exit": receipt["agent_exit"], "upstream_verifier_exit": receipt["verifier_exit"],
            "strict_target_toc_check": strict, "history_reads": reads, "error_types": errors,
            "model_posts": sum(line.startswith("POST ") for line in receipt["model_http_requests"]),
            "locally_denied_requests": sum(line.startswith("DENIED") for line in receipt["model_http_requests"]),
            "reported_tokens": tokens, "elapsed_seconds_including_verifier": receipt["elapsed_seconds"],
            "output_sha256": sha(out) if out.exists() else None,
            "output_canonical_json_sha256": (hashlib.sha256(json.dumps(parsed, ensure_ascii=False,
                sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
                if parsed is not None else None),
            "output_entry_count": len(parsed) if isinstance(parsed, list) else None,
            "raw_sha256": sha(raw_path), "receipt_sha256": sha(receipt_path),
            "intervention_sha256": sha(intervention_path),
            "instruction_sha256": intervention["instruction_sha256"],
            "document_sha256": intervention["document_sha256"],
            "verifier_sha256": intervention["verifier_sha256"], "image_id": intervention["image_id"],
            "markdown_init_sha256": intervention["markdown_init_sha256"],
            "history_input_sha256": intervention["history_input_sha256"]}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("episodes", type=Path)
    parser.add_argument("target_document", type=Path)
    parser.add_argument("qualification", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError("refusing to overwrite an earlier summary")
    specs = [("source_no_history", "office-ind-005__no_history__*"),
             ("target_no_history", "office-ind-006__no_history__*"),
             ("target_raw_history", "office-ind-006__raw_history__*"),
             ("target_generated_skill", "office-ind-006__generated_skill__*"),
             ("target_raw_history_accessfix", "office-ind-006__raw_history_accessfix__*"),
             ("target_generated_skill_accessfix", "office-ind-006__generated_skill_accessfix__*")]
    document = args.target_document.read_text(encoding="utf-8")
    cases = {name: summarize(one(args.episodes, pattern), document if name.startswith("target_") else None)
             for name, pattern in specs}
    target = [value for name, value in cases.items() if name.startswith("target_")]
    for key in ("instruction_sha256", "document_sha256", "verifier_sha256", "image_id", "markdown_init_sha256"):
        if len({x[key] for x in target}) != 1:
            raise ValueError(f"target conditions differ in {key}")
    if sha(args.target_document) != target[0]["document_sha256"]:
        raise ValueError("strict check uses a different target document")
    ledger_path = args.episodes / "source_experience/ledger.json"
    ledger = json.loads(ledger_path.read_text(encoding="utf-8"))
    qual = json.loads(args.qualification.read_text(encoding="utf-8"))
    if ledger.get("status") != "RECEIVED":
        raise ValueError("experience generation was not successfully received")
    if (qual["upstream_results"]["target_wrong_slug_negative"]["exit_code"] != 0
            or qual["strict_target_controls"]["target_wrong_slug_negative"] is not False):
        raise ValueError("qualification does not reproduce the stated verifier counterexample")
    summary = {"status": "EXPOSED_SAME_BENCHMARK_DEVELOPMENT_NOT_CAUSAL_CONFIRMATION",
               "cases": cases, "qualification_sha256": sha(args.qualification),
               "source_skill_author": {"requests": 1, "usage": ledger.get("usage"),
                                       "ledger_sha256": sha(ledger_path), "skill_sha256": ledger.get("skill_sha256"),
                                       "model": ledger.get("response_model")},
               "all_target_canonical_json_equal": (all(x["output_canonical_json_sha256"] is not None for x in target)
                   and len({x["output_canonical_json_sha256"] for x in target}) == 1),
               "total_agent_posts": sum(row["model_posts"] for row in cases.values()),
               "total_reported_agent_tokens": sum(row["reported_tokens"]["total"] for row in cases.values()),
               "total_reported_cache_read": sum(row["reported_tokens"]["cache_read"] for row in cases.values())}
    args.output.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(args.output), "sha256": sha(args.output), "cases": cases,
                      "total_agent_posts": summary["total_agent_posts"],
                      "total_reported_agent_tokens": summary["total_reported_agent_tokens"]}), flush=True)


if __name__ == "__main__":
    main()
