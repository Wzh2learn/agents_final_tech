#!/usr/bin/env python3
"""Run two isolated ContinualSkillBench office tasks using the project harness.

The benchmark, tasks and tests were read by the researcher before this
development run. The agent sees the task and its input document, not the
benchmark's test code or answer/specification files. The upstream evaluator is
mounted separately only after the episode ends. This is not an official run.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys


ROOT = Path("/home/testuser/wzh/research_evidence/agent_learning_20261030")
TASKS = ROOT / "ContinualSkillBench/Continual-Skill-Bench/tasks/office-100-independent-trials"
QUAL = ROOT / "continual_office_qualification_20261103/receipt.json"
OUTPUT = ROOT / "continual_office_agent_20261103"
BASE = Path("/home/testuser/wzh/research_evidence/agent_skill_method_20261029/run_skill_episode_output8192.py")
BASE_HASH = "4111a0be97845740769722e2e596871d51c7693d14d2372d7f6931b4d06e7afb"
MARKDOWN = Path("/usr/lib/python3/dist-packages/markdown")


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def replace_once(text: str, old: str, new: str, count: int = 1) -> str:
    if text.count(old) != count:
        raise ValueError(f"unexpected base-runner fragment: {old[:100]!r}")
    return text.replace(old, new, count)


def prepare(version: int, condition: str, source: Path | None, experience: Path | None):
    if sha(BASE) != BASE_HASH:
        raise ValueError("base runner differs from the pinned copy")
    if version == 5 and condition != "no_history":
        raise ValueError("source task cannot receive target history")
    qual = json.loads(QUAL.read_text(encoding="utf-8"))
    image = subprocess.check_output(["docker", "image", "inspect", "python:3.12-slim",
                                     "--format", "{{.Id}}"], text=True).strip()
    if image != qual["image_id"]:
        raise ValueError("container image differs from qualification")
    if qual["upstream_results"]["source_markdown_baseline"]["exit_code"] != 0 or qual["upstream_results"]["target_regex_baseline"]["exit_code"] != 0:
        raise ValueError("qualification baseline failed")
    src = TASKS / f"office-ind-{version:03d}"
    document = "doc-002_document.md" if version == 5 else "doc-003_document.md"
    which = "source" if version == 5 else "target"
    if sha(src / "instruction.md") != qual["inputs"][f"{which}_instruction"]:
        raise ValueError("task instruction differs from qualification")
    if sha(src / "environment/data" / document) != qual["inputs"][f"{which}_document"]:
        raise ValueError("task document differs from qualification")
    if sha(src / "tests/clawbench_eval.py") != qual["inputs"][f"{which}_verifier"]:
        raise ValueError("test differs from qualification")
    if not MARKDOWN.is_dir():
        raise ValueError("pinned Markdown library directory is missing")

    code = BASE.read_text(encoding="utf-8")
    edits = [
        ("/home/testuser/wzh/research_evidence/agent_skill_method_20261029", str(OUTPUT), 1),
        ("UP=Path('/home/testuser/wzh/research_evidence/agent_frontier_20261029/skillsbench_v1_1/tasks')",
         f"UP=Path({str(TASKS)!r})", 1),
        ("if task not in ('llm-prefix-cache-replay','dialogue-parser','tictoc-unnecessary-abort-detection') or arm not in ('no_skill','all_skill','select_skill'): raise SystemExit('unsupported')",
         "if task not in ('office-ind-005','office-ind-006') or arm != 'no_skill': raise SystemExit('unsupported')", 1),
        ("body=(src/'task.md').read_text(encoding='utf8').split('---',2)[2].strip()",
         "body=(src/'instruction.md').read_text(encoding='utf8').strip()", 1),
        ("target='/app' if task=='dialogue-parser' else '/root'", "target='/app/workspace'", 1),
        ("for name in (('trace.jsonl','config.json') if task=='llm-prefix-cache-replay' else (('script.txt',) if task=='dialogue-parser' else ())):\n    shutil.copy2(src/'environment'/name,work/name)",
         f"name={document!r}\nshutil.copy2(src/'environment'/'data'/name,work/name)", 1),
        ("Never read an entire large trace into the conversation; inspect only the first two lines using shell head, then write code that processes the complete unmodified file.",
         "Read the task input from /app/workspace. The local Python Markdown library is available if useful.", 1),
        ("len(calls)>=8", "len(calls)>=16", 1),
        ("sum(payload_bytes)+length>450000", "sum(payload_bytes)+length>1000000", 1),
        ("'timeout':120000", "'timeout':180000", 1),
        ("[],[],120)", "[],[],180)", 2),
        ("stderr=subprocess.PIPE,timeout=300)", "stderr=subprocess.PIPE,timeout=900)", 1),
        ("'--cpus','1','--cap-drop'", "'--cpus','2','--cap-drop'", 1),
        ("'--memory','2g'", "'--memory','3g'", 1),
        ("server=Server(str(sockpath),Handler);",
         "_at=cmd.index('python:3.12-slim'); "
         "cmd[_at:_at]=['-e','PYTHONPATH=/markdown_lib','--mount',"
         f"'type=bind,src={MARKDOWN},dst=/markdown_lib/markdown,readonly'] + "
         "[z for source,dest in OFFICE_HISTORY for z in "
         "('--mount',f'type=bind,src={source},dst={dest},readonly')]; "
         "server=Server(str(sockpath),Handler);", 1),
        ("sockpath.unlink(missing_ok=True)", "sockpath.unlink(missing_ok=True);bridge.rmdir()", 1),
        ("verifier_command='python -m pytest -q -p no:cacheprovider /verifier/test_outputs.py'",
         "verifier_command=OFFICE_VERIFIER", 1),
        ("'--mount',f'type=bind,src={work},dst={target}', '--mount',f'type=bind,src={src / \"verifier\"},dst=/verifier,readonly'",
         "'--mount',f'type=bind,src={work},dst={target},readonly', '--mount',f'type=bind,src={src / \"tests\"},dst=/verifier,readonly'", 1),
        ("'-e','PYTHONPATH=/deps','-e','PYTEST_DISABLE_PLUGIN_AUTOLOAD=1'",
         "'-e','PYTHONPATH=/verifier','-e','PYTHONDONTWRITEBYTECODE=1'", 1),
        ("case=ROOT/(task+'__'+arm+'__'+str(os.getpid()))",
         f"case=ROOT/(task+'__{condition}__'+str(os.getpid()))", 1),
        ("receipt={'task':task,'arm':arm", f"receipt={{'task':task,'arm':'{condition}'", 1),
    ]
    for old, new, count in edits:
        code = replace_once(code, old, new, count)
    mounts = []
    input_hashes = {}
    if condition != "no_history":
        if source is None or experience is None:
            raise ValueError("source episode and generated experience are required")
        receipt = json.loads((source / "receipt.json").read_text(encoding="utf-8"))
        config = json.loads((experience / "config.json").read_text(encoding="utf-8"))
        if (receipt["task"] != "office-ind-005" or sha(source / "raw.jsonl") != receipt["raw_sha256"]
                or config["source_trace_sha256"] != receipt["raw_sha256"]
                or config["source_receipt_sha256"] != sha(source / "receipt.json")
                or config["source_history_sha256"] != sha(experience / "source_history.json")
                or config["target_task_or_reference_seen_by_author"] is not False):
            raise ValueError("source experience provenance mismatch")
        if condition == "raw_history":
            path = experience / "source_history.json"
            dest = "/root/source_history.json"
        else:
            path = experience / "skill.md"
            dest = "/root/source_skill.md"
            ledger = json.loads((experience / "ledger.json").read_text(encoding="utf-8"))
            if ledger.get("status") != "RECEIVED" or ledger.get("skill_sha256") != sha(path):
                raise ValueError("generated skill provenance mismatch")
            input_hashes["author_ledger_sha256"] = sha(experience / "ledger.json")
        mounts.append((path, dest))
        input_hashes[dest] = sha(path)
        code = replace_once(code, "Use available tools to implement and execute your solution.",
                            f"Before solving, read {dest}, from a previous related task. "
                            "Follow the current task. Use available tools to implement and execute your solution.")
    compile(code, str(BASE), "exec")
    fun = "assert_doc002_markdown_to_html" if version == 5 else "assert_doc003_extract_toc"
    verifier = ("python -c \"from pathlib import Path; from clawbench_eval import " + fun + "; "
                + fun + "(Path('/app/workspace'))\"")
    metadata = {"status": "EXPOSED_DEVELOPMENT_NOT_OFFICIAL_BENCHMARK", "task": version,
                "condition": condition, "benchmark_revision": qual["revision"],
                "qualification_sha256": sha(QUAL), "instruction_sha256": qual["inputs"][f"{which}_instruction"],
                "document_sha256": qual["inputs"][f"{which}_document"],
                "verifier_sha256": qual["inputs"][f"{which}_verifier"], "image_id": image,
                "source_harness_sha256": BASE_HASH, "derived_harness_sha256": hashlib.sha256(code.encode()).hexdigest(),
                "markdown_init_sha256": sha(MARKDOWN / "__init__.py"), "history_input_sha256": input_hashes,
                "max_http": 16, "max_post_body_bytes": 1000000, "max_wall_seconds": 900,
                "model": "qwen3.6-35b-a3b (configured; deployed weight hash not independently verified)",
                "sandbox": "network-free container; limited local model proxy; upstream verifier mounted afterwards"}
    return code, verifier, mounts, metadata


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("task", type=int, choices=(5, 6))
    parser.add_argument("--condition", choices=("no_history", "raw_history", "generated_skill"), default="no_history")
    parser.add_argument("--source-episode", type=Path)
    parser.add_argument("--experience", type=Path)
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    code, verifier, mounts, metadata = prepare(args.task, args.condition, args.source_episode, args.experience)
    print(json.dumps(metadata), flush=True)
    if args.check:
        return
    sys.argv = [str(BASE), f"office-ind-{args.task:03d}", "no_skill"]
    namespace = {"__name__": "__main__", "__file__": str(BASE),
                 "OFFICE_HISTORY": mounts, "OFFICE_VERIFIER": verifier}
    try:
        exec(compile(code, str(BASE), "exec"), namespace)
    finally:
        case = namespace.get("case")
        if case is not None and case.is_dir():
            (case / "intervention.json").write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
