#!/usr/bin/env python3
"""Build source-only history and one generated skill from an office episode."""

from __future__ import annotations

import argparse
import datetime
import hashlib
import json
from pathlib import Path
import time
import urllib.error
import urllib.request


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source_episode", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--generate-prepared", action="store_true")
    args = parser.parse_args()
    if args.prepare_only and args.generate_prepared:
        raise ValueError("choose at most one preparation option")
    source = args.source_episode.resolve()
    receipt = json.loads((source / "receipt.json").read_text(encoding="utf-8"))
    raw = source / "raw.jsonl"
    if receipt["task"] != "office-ind-005" or receipt["raw_sha256"] != sha(raw):
        raise ValueError("source task or raw hash differs")
    events = [json.loads(line) for line in raw.read_text(encoding="utf-8").splitlines() if line.strip()]
    actions = []
    errors = []
    for event in events:
        if event.get("type") == "error":
            errors.append(event.get("error", {}).get("name", "UNKNOWN"))
        part = event.get("part", {})
        state = part.get("state", {})
        if event.get("type") == "tool_use" and state.get("status") == "completed":
            inputs = state.get("input", {})
            if "output.html" in json.dumps(inputs, ensure_ascii=False):
                output = str(state.get("output", ""))
                actions.append({"tool": part.get("tool"), "input": inputs,
                                "output_tail": output[-700:], "output_chars": len(output)})
    answer = source / "work/output.html"
    if not actions or not answer.is_file():
        raise ValueError("source output or its recorded action is missing")
    compact = {"source_instruction": (source / "work/instructions.txt").read_text(encoding="utf-8"),
               "source_output_html": answer.read_text(encoding="utf-8")[:8000],
               "source_actions": actions[-4:], "source_error_types": errors,
               "source_feedback": {"agent_exit": receipt["agent_exit"],
                                   "upstream_verifier_exit": receipt["verifier_exit"]},
               "compaction": "last four completed actions mentioning source output; output tail capped at 700 characters; no target task or reference"}
    config = {"status": "EXPOSED_DEVELOPMENT_SOURCE_ONLY", "source_trace_sha256": sha(raw),
              "source_receipt_sha256": sha(source / "receipt.json"),
              "source_instruction_sha256": sha(source / "work/instructions.txt"),
              "source_output_sha256": sha(answer),
              "target_task_or_reference_seen_by_author": False,
              "max_tokens": 1600, "temperature": 0, "max_http_attempts": 1}
    if args.generate_prepared:
        if not args.output.is_dir() or any((args.output / name).exists() for name in ("request.json", "ledger.json", "response.json", "skill.md")):
            raise ValueError("prepared output missing or generation attempted")
        history = args.output / "source_history.json"
        if json.loads(history.read_text(encoding="utf-8")) != compact:
            raise ValueError("prepared source history changed")
    else:
        args.output.mkdir(parents=True, exist_ok=False)
        history = args.output / "source_history.json"
        write_json(history, compact)
    config["source_history_sha256"] = sha(history)
    if args.generate_prepared:
        if json.loads((args.output / "config.json").read_text(encoding="utf-8")) != config:
            raise ValueError("prepared configuration changed")
    else:
        write_json(args.output / "config.json", config)
    if args.prepare_only:
        print(json.dumps(config), flush=True)
        return
    messages = [{"role": "system", "content": (
        "Create concise, reusable instructions from a past tool-using agent episode and its feedback. "
        "Separate general steps from task-specific choices; include failures and unresolved assumptions. "
        "Do not invent results or include the past output as a future answer. Return only the skill text.")},
        {"role": "user", "content": json.dumps(compact, ensure_ascii=False)}]
    payload = {"model": "Qwen3.6-35B-A3B-Q4_K_M.gguf", "messages": messages,
               "temperature": 0, "max_tokens": 1600, "chat_template_kwargs": {"enable_thinking": False}}
    request_file = args.output / "request.json"
    request_file.write_text(json.dumps(payload, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    event = {"status": "ATTEMPT_STARTED", "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
             "request_sha256": sha(request_file), "usage": None}
    ledger = args.output / "ledger.json"
    write_json(ledger, event)
    start = time.monotonic()
    request = urllib.request.Request("http://127.0.0.1:8004/v1/chat/completions",
                                     data=request_file.read_bytes(),
                                     headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(request, timeout=240) as response:
            response_bytes = response.read()
        response_path = args.output / "response.json"
        response_path.write_bytes(response_bytes)
        result = json.loads(response_bytes)
        event["usage"] = result.get("usage")
        event["response_model"] = result.get("model")
        choice = result["choices"][0]
        event["finish_reason"] = choice.get("finish_reason")
        text = choice["message"].get("content") or ""
        if not text.strip():
            raise ValueError("empty model content")
        skill = args.output / "skill.md"
        skill.write_text(text, encoding="utf-8")
        event.update({"status": "RECEIVED", "response_sha256": sha(response_path), "skill_sha256": sha(skill)})
    except (urllib.error.URLError, TimeoutError, OSError, ValueError, KeyError, TypeError, IndexError) as exc:
        event.update({"status": "FAILED_USAGE_MAY_BE_UNKNOWN", "error_type": type(exc).__name__})
    event["elapsed_seconds"] = time.monotonic() - start
    write_json(ledger, event)
    print(json.dumps(event), flush=True)


if __name__ == "__main__":
    main()
