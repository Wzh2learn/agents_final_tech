#!/usr/bin/env python3
"""Qualify two public office tasks without exposing verifier files to an agent.

This is a post-hoc, developer-exposed adaptation, not an official benchmark
run. Inputs and generated files stay under the supplied private evidence root.
"""

from __future__ import annotations

import hashlib
import importlib.metadata
import json
from pathlib import Path
import re
import subprocess
import sys

import markdown


BASE = Path("/home/testuser/wzh/research_evidence/agent_learning_20261030/ContinualSkillBench")
EXPECTED_REVISION = "91c76f887c2a422d1f8d4c1adacc944c9c2ad6c1"
TASKS = BASE / "Continual-Skill-Bench/tasks/office-100-independent-trials"
DEST = Path("/home/testuser/wzh/research_evidence/agent_learning_20261030/continual_office_qualification_20261103")
IMAGE = "python:3.12-slim"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def get_task(number: int) -> Path:
    return TASKS / f"office-ind-{number:03d}"


def baseline_toc(text: str) -> list[dict]:
    entries = []
    for line in text.splitlines():
        match = re.match(r"^(#{1,6})\s+(.+?)\s*$", line)
        if not match:
            continue
        title = match.group(2)
        slug = re.sub(r"[^a-z0-9 -]", "", title.lower()).replace(" ", "-")
        slug = re.sub(r"-+", "-", slug).strip("-")
        entries.append({"level": len(match.group(1)), "title": title, "slug": slug})
    return entries


def check_toc(entries: object, document: str) -> bool:
    """Check each output against document order and the task's slug contract."""
    if not isinstance(entries, list):
        return False
    headings = [re.match(r"^(#{1,6})\s+(.+?)\s*$", line) for line in document.splitlines()]
    headings = [match for match in headings if match]
    if len(entries) != len(headings):
        return False
    for row, heading in zip(entries, headings):
        if not isinstance(row, dict) or row.get("level") != len(heading.group(1)):
            return False
        if row.get("title") != heading.group(2):
            return False
        slug = row.get("slug")
        if not isinstance(slug, str) or not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", slug):
            return False
        expected = re.sub(r"[^a-z0-9 -]", "", heading.group(2).lower()).replace(" ", "-")
        expected = re.sub(r"-+", "-", expected).strip("-")
        if slug != expected:
            return False
    return True


def upstream_check(task: int, workspace: Path) -> dict:
    fn = {5: "assert_doc002_markdown_to_html", 6: "assert_doc003_extract_toc"}[task]
    code = (f"from pathlib import Path; from clawbench_eval import {fn}; "
            f"{fn}(Path('/workspace'))")
    cmd = ["docker", "run", "--rm", "--network", "none", "--read-only", "--cpus", "1",
           "--memory", "512m", "--pids-limit", "64", "--cap-drop", "ALL",
           "--security-opt", "no-new-privileges", "-e", "PYTHONDONTWRITEBYTECODE=1",
           "-e", "PYTHONPATH=/verifier", "--mount", f"type=bind,src={get_task(task) / 'tests'},dst=/verifier,readonly",
           "--mount", f"type=bind,src={workspace},dst=/workspace,readonly", IMAGE, "python", "-c", code]
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                          text=True, timeout=60, check=False)
    return {"exit_code": proc.returncode, "output_tail": proc.stdout[-1000:]}


def main() -> None:
    revision = subprocess.check_output(["git", "-C", str(BASE), "rev-parse", "HEAD"], text=True).strip()
    if revision != EXPECTED_REVISION:
        raise ValueError("source benchmark revision changed")
    if subprocess.run(["git", "-C", str(BASE), "diff", "--quiet", "HEAD"], check=False).returncode != 0:
        raise ValueError("source benchmark has tracked changes")
    image_id = subprocess.check_output(["docker", "image", "inspect", IMAGE, "--format", "{{.Id}}"], text=True).strip()
    DEST.mkdir(parents=True, exist_ok=False)
    src = get_task(5)
    dst = get_task(6)
    doc_src = src / "environment/data/doc-002_document.md"
    doc_dst = dst / "environment/data/doc-003_document.md"
    source_work = DEST / "source_baseline"
    target_work = DEST / "target_baseline"
    negative_work = DEST / "target_bad_slug"
    for folder in (source_work, target_work, negative_work):
        folder.mkdir()
    (source_work / "output.html").write_text(markdown.markdown(doc_src.read_text(encoding="utf-8"), extensions=["fenced_code"]), encoding="utf-8")
    document = doc_dst.read_text(encoding="utf-8")
    toc = baseline_toc(document)
    (target_work / "toc.json").write_text(json.dumps(toc, ensure_ascii=False, indent=2), encoding="utf-8")
    bad = [dict(row) for row in toc]
    if not bad:
        raise ValueError("target document has no headings")
    bad[0]["slug"] = "!"
    (negative_work / "toc.json").write_text(json.dumps(bad, ensure_ascii=False, indent=2), encoding="utf-8")
    results = {"source_markdown_baseline": upstream_check(5, source_work),
               "target_regex_baseline": upstream_check(6, target_work),
               "target_wrong_slug_negative": upstream_check(6, negative_work)}
    strict = {"target_baseline": check_toc(toc, document),
              "target_wrong_slug_negative": check_toc(bad, document)}
    if (results["source_markdown_baseline"]["exit_code"] != 0
            or results["target_regex_baseline"]["exit_code"] != 0
            or strict != {"target_baseline": True, "target_wrong_slug_negative": False}):
        raise AssertionError("baseline or independent heading controls did not behave as expected")
    receipt = {"status": "EXPOSED_DEVELOPMENT_NOT_OFFICIAL_BENCHMARK",
               "revision": revision, "code_license": "Apache-2.0; derived tasks retain upstream terms",
               "python": sys.version, "python_markdown": importlib.metadata.version("Markdown"),
               "image_id": image_id,
               "inputs": {"source_instruction": sha(src / "instruction.md"),
                          "target_instruction": sha(dst / "instruction.md"),
                          "source_document": sha(doc_src), "target_document": sha(doc_dst),
                          "source_verifier": sha(src / "tests/clawbench_eval.py"),
                          "target_verifier": sha(dst / "tests/clawbench_eval.py")},
               "upstream_results": results, "strict_target_controls": strict,
               "target_headings": len(toc), "model_calls": 0}
    out = DEST / "receipt.json"
    out.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"receipt": str(out), "sha256": sha(out), "results": results,
                      "strict_target_controls": strict}), flush=True)


if __name__ == "__main__":
    main()
